<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=FF0000&center=true&width=1000&height=200&lines=XEON-XMD" alt="Typing SVG" /></a>
  </p>
+

> **`Updated` XEON XMD with Latest Features**

## CONTACT XEON-XMD TECH
  
<a href="https://wa.me/254759000340"> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/WhatsApp.png" width="13%"> </a>
  <a href="https://chat.whatsapp.com/GbpVWoHH0XLHOHJsYLtbjH"> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/WhatsApp.png" width="13%"> </a>
  <a href="https://www.facebook.com/profile.php?id=100086056192263&name=xhp_nt__fb__action__open_use"> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/Instagram2.png" width="14%"> </a>
  <a href="https://www.instagram.com/bright_leizer_?igsh=Y2JmcnE1ajNjZXM=&name=xhp_nt__fb__action__open_user"> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/Facebook.png" width="15%"> </a><a href="https://github.com/Black-Tappy/XEON-XMD/tree/main"> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/devto.png" width="15%"> </a><a href="XEON "> <img src="https://raw.githubusercontent.com/shizothetechie/database/main/icon/twitter.png" width="13%"> </a>
</p>


```
𝐗𝐄𝐎𝐍 𝐗𝐌𝐃 𝐁𝐘 Ⴊl𐌀Ꮳk𐌕𐌀ႲႲჄ 🩷 
```

--- 

<a><img src='https://files.catbox.moe/78hoyu.jpg'/></a>

---

<p align="center">
  <a href="https://github.com/Black-Tappy "><img title="Developer" src="https://img.shields.io/badge/Author-Black%20Tappy-FF7604.svg?style=big-square&logo=github" /></a>
</p>

<div align="center">
  
[![WhatsApp Channel](https://img.shields.io/badge/Join-WhatsApp%20Channel-FF00F8?style=big-square&logo=whatsapp)](https://whatsapp.com/channel/0029VasHgfG4tRrwjAUyTs10)
</div>

 <p align="center"><img src="https://profile-counter.glitch.me/{XEON-XMD}/count.svg" alt="Black-Tappy :: Visitor's Count" old_src="https://profile-counter.glitch.me/{Black-Tappy}/count.svg" /></p>


<p align="center">
<a href="https://github.com/Black-Tappy/XEOM-XMD"><img title="PUBLIC-BOT" src="https://img.shields.io/static/v1?label=Language&message=English&style=square&color=darkpink"></a> &nbsp;
  <img src="https://komarev.com/ghpvc/?username=XEON-XMD&label=VIEWS&style=square&color=blue" />
</p>
</p> 

### 1. Fork This Repository

Click the button below to fork:

  <a href="https://github.com/Black-Tappy/XEON-XMD/fork"><img title="XEON-XMD" src="https://img.shields.io/badge/FORK-XEON XMD-h?color=green&style=for-the-badge&logo=stackshare"></a>

## ɢᴇᴛ ᴘᴀɪʀɪɴɢ ᴄᴏᴅᴇ
  <p align="left">  
<a href='https://popkidxtech-session.onrender.com/pair' target="_blank"><img alt='Get Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-000000?style=for-the-badge&logo=codefactor&logoColor=yellow'/></a>  
</p>  


## 👻 ᴅᴇᴘʟᴏʏ xᴇᴏɴ xᴍᴅ 👻

> Deploy on Heroku



<p align="left">  
<a href='https://dashboard.heroku.com/new?template=https://github.com/Black-Tappy/XEON-XMD/tree/main' target="_blank"><img alt='Deploy on Heroku' src='https://img.shields.io/badge/Deploy%20on-Heroku-FF004D?style=for-the-badge&logo=heroku&logoColor=white'/></a>  
</p>



## ᴄʀᴇᴅɪᴛs ᴀɴᴅ ᴅᴇᴠs
> XEON-XMD Owner 
- [Black-Tappy](https://github.com/Black-Tappy)
- Creater and Owner Of REDMAGIC-XMD 
> XEON-XMD Helpers 
- [POPKID](https://github.com/Popkiddevs)
- For helping in bot plugin files.
  



🔒 Final Note

If you face any issues, report them on GitHub or in the WhatsApp community.
Happy coding! 👻 
